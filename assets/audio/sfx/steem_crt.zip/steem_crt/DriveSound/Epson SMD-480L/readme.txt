Epson SMD-480L sound sampled by Stefan jL, thx dude!
